package klm.Maven;

public class TestData {
	public static final String Firefox_browser = null;
	public String baseUrl = "https://www.klm.com/home/nl/en";
	String driverPath = "C:\\Users\\Sparkelon\\Desktop\\Alekhya\\SeleniumNew\\drivers\\geckodriver.exe";
	
	
}
